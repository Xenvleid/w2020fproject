OTF and TTF: Red Seven (Regular, Italic, and Outlines)
Dennis Ludlow 2016 all rights reserved
by Sharkshock 
dennis@sharkshock.net


Looking for a sharp typeface that can take you places? How about one that can slice through a tomato can? Red Seven is an edgy, futuristic display font that lends itself to lettering, titles, and logos. It features an ultra sleek even weight that repeats itself through all of the characters. Inspiration came 
from bands, exotic cars, sci-fi movies, and college sports teams. Use uppercase for more emphasis on the angled bars or lowercase for more legible text, but not together. To be consistent with styling It's recommended that you stay with one or the other. There are some alternates and one stylistic 
set built in which compliments the angular styling of the uppercase members. Basic/extended latin are featured with kerning, basic punctuation, European accents, and diacritics. Italic and Outline version are available with purchase of commercial license.


This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license agreement. You can also visit www.sharkshock.net/license for more info. I also design custom fonts for 
businesses, logos, and many other things. If you'd like to leave me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

tags: sans serif, sans, display, font, publishing, title, science, fiction, sci fi, sports, team, edgy, sharp, sleek, space, aliens, alien, war, college, pro, razor, car, fast, title, logo, luxury, band, metal, techno

visit www.sharkshock.net for more and take a bite out of BORING design!

